﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment5
{
    class Program
    {
        
        static void Main(string[] args)
        {
            //Main Function
            ArrayAss a = new ArrayAss();
            a.ArrayExe();
            a.Diagsum();
            a.JaggedArray();
            a.SumofEachRow();
            a.AssciToChar();

        }
    }

    class ArrayAss
    {
        public void ArrayExe()
        {
            Console.WriteLine("--- SUM OF ARRAY ---");
            int[] arr1 = { 1, 2, 3 }; //Array
            int sum = 0;
            for (int i = 0; i <= 2; i++)
            {
                int temp = arr1[i];
                sum = sum + temp; //addition of array elements
            }
            Console.WriteLine(sum);0
            Console.ReadLine();

        }

        public void SumofEachRow()
        {
            Console.WriteLine("--- SUM OF EACH ROW ---");
            int[,] num = new int[3, 3];// Array
            num[0, 0] = 10; num[0, 1] = 40; num[0, 2] = 50;
            num[1, 0] = 60; num[1, 1] = 20; num[1, 2] = 70;
            num[2, 0] = 80; num[2, 1] = 90; num[2, 2] = 30;

            for (int i=0;i<3;i++)
            {
                for (int j=0;j<3;j++)
                {
                    Console.Write("{0}\t", num[i, j]); //Printing Array
                }
                Console.WriteLine();
            }
            int r1 = num[0, 0] + num[0, 1] + num[0, 2];
            int r2 = num[1, 0] + num[1, 1] + num[1, 2];
            int r3 = num[2, 0] + num[2, 1] + num[2, 2];
            Console.WriteLine("Sum Of Numbers Are");
            Console.WriteLine("{0}\t{1}\t{2}", r1, r2, r3); //Printing sum of each array;
            Console.ReadLine();

        }
        public void AssciToChar()
        {
            Console.WriteLine("--- CHAR TO ASCII CONVERSION ---");
            char[,] num = new char[3, 3]; //Array
            num[0, 0] = 'a'; num[0, 1] = 'b'; num[0, 2] = 'c';
            num[1, 0] = 'd'; num[1, 1] = 'e'; num[1, 2] = 'f';
            num[2, 0] = 'g'; num[2, 1] = 'h'; num[2, 2] = 'i';
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", num[i, j]); //Printing Array
                }
                Console.WriteLine();
            }

            Console.WriteLine("Ascii Values");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t",Convert.ToInt32( num[i, j])); //Printing ASCII Values 
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }

        public void Diagsum()
        {
            Console.WriteLine("--- DAIOGNAL SUM --- ");
            int[,] num = new int[3, 3]; //Array
            num[0, 0] = 10; num[0, 1] = 40; num[0, 2] = 50;
            num[1, 0] = 60; num[1, 1] = 20; num[1, 2] = 70;
            num[2, 0] = 80; num[2, 1] = 90; num[2, 2] = 30;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", num[i, j]);//Printing Array
                }
                Console.WriteLine();
            }
            int sum = num[0, 0] + num[1, 1]+ num[2, 2];
            Console.WriteLine("Daigonal Sum Of Numbers is");
            Console.WriteLine("{0}\t", sum);//Printing Daigonal sum
            Console.ReadLine();
        }

        public void JaggedArray()
        {
            Console.WriteLine(" --- JAGGED ARRAY ---");
            int[][] num = new int[2][]; //Jagged array
            num[0] = new int[] {1,4,5,6,8,9 };
            num[1] = new int[] {14,15,78,45,90,77 };

            foreach(int temp in num[0])
            {
                Console.Write("{0}\t", temp);
            }
            Console.WriteLine();
            foreach (int temp in num[1])
            {
                Console.Write("{0}\t", temp);
            }
            Console.WriteLine();

            Console.WriteLine("Enter the number to be searched");
            int number = Convert.ToInt32(Console.ReadLine());
            int n = 0;
            foreach(int temp in num[0])// Foreach loop to search number
            {
                if(number==temp)
                {
                    n = 1;
                }
                
            }
            foreach (int temp in num[1])
            {
                if (number == temp)
                {
                    n = 1;
                }
                
            }
            Console.WriteLine();
            if (n == 1)
            {
                Console.WriteLine("Number Found...");
            }
            else
            {
                Console.WriteLine("Number not Found");
            }
            Console.ReadLine();
        }
    }
}
