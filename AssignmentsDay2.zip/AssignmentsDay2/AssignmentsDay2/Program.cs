﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentsDay2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Main Function
            Assignments3 c = new Assignments3();
            c.ifelse();
            c.Percentage();
            c.switchcase();
            c.tarnary();
        }

    }
    class Assignments3 { 
        public void ifelse()
        {
            Console.WriteLine("--- MAJOR OR MINOR ---");
            Console.WriteLine("Enter Your Age");
            int Age = Convert.ToInt32(Console.ReadLine()); //Accepting User Input

            if (Age >= 18) //Checking Input
            {
                Console.WriteLine("You are Major");
            }
            else
            {
                Console.WriteLine("you are Minor");
            }
            Console.ReadLine();
        }

        public void Percentage()
        {
            Console.WriteLine("--- GREAD ON GIVEN PERCENTAGE ---");
            Console.WriteLine("Enter Your Percentage");
            int per = Convert.ToInt32(Console.ReadLine());//Accepting User Input

            if (per> 65 )//Checking Input
            {
                Console.WriteLine("Your Grade Is A+");
            }

            else if (per<65 && per>60)//Checking Input
            {
                Console.WriteLine("Your Gread is A");
            }
            else if(per <60 && per>50)//Checking Input
            {
                Console.WriteLine("Your Gread is B");

            }
            else
            {
                Console.WriteLine("Your Gread is C");
            }
            Console.ReadLine();
        }

        public void switchcase()
        {
            Console.WriteLine("--- SWITCH CASE: DAY ON GIVEN NUMBER ---");
            Console.WriteLine("Select a Number : 1,2,3,4,5,6,7");
            string day = Console.ReadLine(); ////Accepting User Input
            switch (day) 
            {
                case "1": Console.WriteLine("Sunday");
                    break;
                case "2": Console.WriteLine("Monday");
                    break;
                case "3": Console.WriteLine("Tuseday");
                    break;
                case "4": Console.WriteLine("Wednesday");
                    break;
                case "5":
                    Console.WriteLine("Thursday");
                    break;
                case "6":
                    Console.WriteLine("Friday");
                    break;
                case "7":
                    Console.WriteLine("Saturday");
                    break;
            }
            Console.ReadLine();
        }

        public void tarnary()
        {
            Console.WriteLine("--- TARANARY OPERATOR MAJOR OR MINOR ---");
            Console.WriteLine("Enter your age");
            int age = Convert.ToInt32(Console.ReadLine());//Accepting User Input
            string outcome = age > 18 ? "you are major" : "You are minor"; // Taranary Operator
            Console.WriteLine(outcome);
            Console.ReadLine();
        }

    }
}
    

