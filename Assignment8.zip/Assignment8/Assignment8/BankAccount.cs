﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    interface IBankAccount //Interface Bank Account
    {
         void Deposit(decimal _amount);
         void Withdraw(decimal _amount);
    }

    class SavingsAccount : IBankAccount
    {
        private decimal _balance;
        private decimal _perdaylimit;


        public void Deposit(decimal _amount)
        {
            _balance += _amount; //Adding amount in to Balance
        }
        public void Withdraw(decimal _amount)
        {

            if (_balance < _amount) //Checking if amount to be withdrawn is greater than avilable balance
            {
                Console.WriteLine("Sorry Insufficiant Balance");
            }

            else if (_perdaylimit + _amount > 5000)
            {
                Console.WriteLine("Daily Withdrawal Limit Exceede");// Checking if Daily Withdrawal limit is exceeded
            }
            else
            {
                _balance -= _amount; // Amount deduction from account

                Console.WriteLine("Succsessfull Withdrawn {0}", _amount);
                Console.WriteLine("Remaining Account balance in Savings Account is {0}", _balance);
            }


        }


    }
    class CurrentAccount : IBankAccount
    {
        private decimal _balance;
        public void Deposit(decimal _amount)
        {
            _balance += _amount;// Adding amount in to Balance

        }
        public void Withdraw(decimal _amount)
        {
            if (_amount > _balance)
            {
                Console.WriteLine("Sorry insufficiant balance");
            }
            else
            {
                _balance -= _amount;// Amount deduction from account
                Console.WriteLine("Amount Withdrawn Succsessfully");
                Console.WriteLine("Remaining Account Balance in Current Account is {0}", _balance);
            }

        }

    }
}



