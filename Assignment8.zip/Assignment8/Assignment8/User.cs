﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    class User
    {
        private long _id;
        private string _name;
        private string _emailid;
        private string _dateofBirth;

        public User()
        {
            
        }
        public User(long _id, string _name,string _emailid,string _dateofBirth)
        {
            this._id = _id;
            this._name = _name;
            this._emailid = _emailid;
            this._dateofBirth = _dateofBirth;
        }

        public override string ToString()
        {
            return string.Format("Id: {0}\nName: {1}\nEmail Id: {2}\nDate of birth: {3}",_id,_name,_emailid,_dateofBirth);
        }

        public long Id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }
    }
}
