﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    
     abstract class Computer
    {
        public string BootUp()
        {
            return "Computer is Booting Up (Functions of Abstract Class Computer)";
        }
         public string ShutDown()
        {
            return "Computer is Shutting Down (Functions of Abstract Class Computer)";
        }
    }

    class SuperComputer:Computer
    {
        public SuperComputer()
        {
            Console.WriteLine( "Calling From Super Computer");
        }

    }
    class MainfraimComputer : Computer
    {
        public MainfraimComputer()
        {
            Console.WriteLine("Calling From Mainfraim Computer");
        }

    }
    class MicroComputer : Computer
    {
        public MicroComputer()
        {
            Console.WriteLine("Calling From Micro Computer");
        }

    }

    abstract class ComputerCall
    {
       static void Main()
        {
            SuperComputer Ca = new SuperComputer();
            Console.WriteLine(Ca.BootUp());
            Console.WriteLine(Ca.ShutDown());
            Console.ReadLine();

            MainfraimComputer Ma = new MainfraimComputer();
            
                Console.WriteLine(Ca.BootUp());
                Console.WriteLine(Ca.ShutDown());
            Console.ReadLine();


            MicroComputer MC = new MicroComputer();
            
                Console.WriteLine(Ca.BootUp());
                Console.WriteLine(Ca.ShutDown());
            Console.ReadLine();

            //Sealed Class
            Console.WriteLine("--- Sealed Class ---");
            Pen p = new Pen();
                p.StartWriting();
                p.StoptWriting();
                Console.ReadLine();
            


            //Room Class

            Console.WriteLine("--- Room Details ---");
            Console.WriteLine("Enter Room Number");
            int _number1 =Convert.ToInt32( Console.ReadLine());
            Console.WriteLine("Enter Floor Number");
            int _floor1=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Room Type");
            string _type1 = Console.ReadLine();
            Console.WriteLine("Enter Room Capacity");
            int _capacity1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Booking Date in YYYY/MM/DD");
            DateTime _bookedTime1 = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter Price of Room");
            double _price1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("\n");

            Room R = new Room(_number1, _floor1, _type1, _capacity1,_bookedTime1, _price1);

            Console.WriteLine(R.ToString());

            Console.ReadLine();


            //User Class
            Console.WriteLine("--- Fourm User Details ---");
            Console.WriteLine("Enter ID");
            long _id1 = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("Enter Name");
            string _name1 = Console.ReadLine();
            Console.WriteLine("Enter Email id");
            string _EmailId1 = Console.ReadLine();
            Console.WriteLine("Enter Date of Birth");
            string _dateofBirth1 = Console.ReadLine();
            Console.WriteLine("\n");

            User U = new User(_id1, _name1, _EmailId1, _dateofBirth1);
            Console.WriteLine(U.ToString());
            Console.ReadLine();

            //Banking Program Using Interface
            //Savings Account
            Console.WriteLine("Account Type: Savings");

            
            Console.WriteLine("Enter Amount To be Deposited");
            decimal amt = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("Enter Amount To be WithDrawn");
            decimal _amount = Convert.ToDecimal(Console.ReadLine());
            SavingsAccount Saveing = new SavingsAccount();
            Saveing.Deposit(amt);
            Saveing.Withdraw(_amount);
            Console.ReadLine();

            //Current Account
            Console.WriteLine("Account Type: Current");
            Console.WriteLine("Enter Amount To be Deposited");
            decimal amt1 = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("Enter Amount To be WithDrawn");
            decimal _amount1 = Convert.ToDecimal(Console.ReadLine());

            CurrentAccount Current = new CurrentAccount();
            Current.Deposit(amt1);
            Current.Withdraw(_amount1);
            Console.ReadLine();

        }


    }

    }
