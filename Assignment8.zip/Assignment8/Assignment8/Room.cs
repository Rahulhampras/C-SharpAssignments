﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    class Room
    {
        private int _number;
        private int _floor;
        private string _type;
        private int _capacity;
        private DateTime _bookedTime;
        private double _price;

        public Room()
        {
            Console.WriteLine("Defualt Constructor of Room");
        }
        public Room(int _number,int _floor, string _type, int _capacity,DateTime _bookedTime ,double _price)
        {
            this._number = _number;
            this._floor = _floor;
            this._type = _type;
            this._capacity = _capacity;
           this._bookedTime = _bookedTime;
            this._price = _price;

        }

        public override string ToString()
        {
            return string.Format("Number= {0}\nFloor= {1}\nType= {2}\nCapacity= {3}\nBooked Time {4}\nPrice= {5}$\n", _number, _floor, _type, _capacity,_bookedTime, _price);
        }

        public int RoomNumber
        {
            get
            {
                return _number;
            }
            set
            {
                _number = value;
            }
        }

        public int Floor
        {
            get
            {
                return _floor;
            }
            set
            {
                _floor = value;
            }
        }

        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }

        public int Capacity
        {
            get
            {
                return _capacity;
            }
            set
            {
                _capacity = value;
            }
        }
        public DateTime BookedTime
        {
            get
            {
                return _bookedTime;
            }
            set
            {
                _bookedTime = value;
            }
        }

        public double Price
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }
    }
}
