﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
     sealed class Pen
    {
        public void StartWriting()
        {
            Console.WriteLine("Calling From Start Writing Function");
        }
        public  void StoptWriting()
        {
            Console.WriteLine("Calling From Stop Writing Function");

        }
        

       
    }
    
     

    
    
}
