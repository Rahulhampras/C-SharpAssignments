﻿using System;
using System.Collections.Generic;


namespace Assignment10
{
    public static class Extension
    {
        public static bool PositiveNeg(this int a, int value)
        {
            if (a < 0) //checking if number is negative
            {
                Console.WriteLine("Number is Negative");
            }
            else if (a >= 0)
            {
                Console.WriteLine("addition is {0}", a + value);

            }
            return true;

        }
    }
    
}
