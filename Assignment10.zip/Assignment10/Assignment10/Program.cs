﻿using System;
using System.Collections.Generic;
using GST;//using DLL file GST
namespace Assignment10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--- Calculating GST Using DLL File ---");
            Console.WriteLine("Enter Amount");
            int amt = Convert.ToInt32(Console.ReadLine()); //Taking Input From User
            Console.WriteLine("Enter GST in Percentage");
            int gst = Convert.ToInt32(Console.ReadLine());
            GST1 g = new GST1();
            double clgst;
           
            Console.WriteLine($"Total Amount after applying {gst} Percent is {g.GST2(amt, gst, out clgst)}");
            Console.WriteLine($"Total GST is {clgst}");
            Console.ReadLine();


                Console.WriteLine("--- Extension ---");
                int a = 50; //Value is Positive so out put will be addition
                bool result = a.PositiveNeg(100);
                Console.WriteLine(result);
            Console.ReadLine();
            
        }
    }
}
