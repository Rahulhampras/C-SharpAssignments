﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GST
{
   public class GST1
    {
        public double GST2(int amt, int gst, out double calculatedgst)
        {
            calculatedgst = ((amt * gst) / 100);
            Console.WriteLine("GST Applied", gst);
            return amt + calculatedgst;
        }
    }
}
