﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    class Program
    {
        static void Main(string[] args)
        {
            //Main Function
            Console.WriteLine("Enter Roll Number");
            int Rollno = Convert.ToInt32(Console.ReadLine());//Accepting User Input
            Console.WriteLine("Enter Student Name");
            string StudentName = (Console.ReadLine());//Accepting User Input
            Console.WriteLine("Enter Gender M: for Male and F:for Female");
            string Gender =(Console.ReadLine());//Accepting User Input
            Console.WriteLine("Enter Mobile Number");
            long MobileNumber = Convert.ToInt64(Console.ReadLine());//Accepting User Input
            student std = new student(Rollno,StudentName,Gender,MobileNumber);

            Console.WriteLine(std.Display());// Calling display Function
            Console.ReadLine();


            Console.WriteLine("Names of cities");
            foreach (string dat in Enum.GetNames(typeof(Citypin.City.CityNames)))
            {
                Console.WriteLine(dat);
            }
            Console.WriteLine("Pincode of cities");
            foreach (int pin in Enum.GetValues(typeof(Citypin.City.CityNames)))
            {
                Console.WriteLine(pin);
            }
            Console.ReadLine();
        }
    }


    struct student
    {
        int Studemtroll;
        string StudentName;
        string Gender;
        long MobileNumber;

        public student(int Studemtroll, string StudentName, string Gender, long MobileNumber)//Constructor
        {
            this.Studemtroll=Studemtroll;
            this.StudentName = StudentName;
            this.Gender = Gender;
            this.MobileNumber = MobileNumber;
        }

        public string Display()
        {
            return string.Format(" Roll Number of student {0}\n Name of student {1}\n Gender of student {2} \n Mobile Number of student {3} ", Studemtroll, StudentName, Gender, MobileNumber); //Printing Output

        }
    }

    class Citypin
    {
        public struct City
        {
            public enum CityNames
            {
                Auranagabad = 0240, pune = 020, Mumbai = 010, nahsik = 025
            };

        }
        
    }

}
