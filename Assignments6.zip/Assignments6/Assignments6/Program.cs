﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments6
{
    class Program
    {
        static void Main(string[] args)
        {
            //Main Function
            ASS6 a = new ASS6();

            Console.WriteLine("Enter amount");
            int amt = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("GST 1% IS :{0} ", a.GST(amt));
            Console.WriteLine("GST 5% IS :{0} ", a.GST(amt,5));
            Console.ReadLine();


            Console.WriteLine("Enter Amount");
            int pa = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Rate of intersest");
            int ri = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Amount time in months");
            int t = Convert.ToInt32(Console.ReadLine());
            double si;
            Console.WriteLine("Total amount is {0} ", a.SimplInt2(pa, ri, t, out si));
            Console.WriteLine("total interest {0} ", si);
            Console.ReadLine();
            a.SimpleInterest();
            a.JaggedArray();
            a.Factorial();
        }
      
      
    }
    class ASS6
    {
        public void Factorial()
        {
            Console.WriteLine("--- Factorial Of Given Number ----");
            Console.WriteLine("Enter Any Number");
            int n = Convert.ToInt32(Console.ReadLine());// Accepting input from user
            int fact = 1;
            for (int i =1; i<=n; i++)
            {
                fact = fact * i;
            }
            Console.WriteLine(fact);
            Console.ReadLine();
        }
        public void JaggedArray()
        {
            Console.WriteLine("--- Serching Number in Jagged Array ----");
            Console.WriteLine("JAGGED ARRAY ");
            int[][] num = new int[2][];//jagged array
            num[0] = new int[] { 1, 4, 5, 6, 8, 9 };
            num[1] = new int[] { 14, 15, 78, 45, 90, 77 };

            foreach (int temp in num[0])
            {
                Console.Write("{0}\t", temp);
            }
            Console.WriteLine();
            foreach (int temp in num[1])
            {
                Console.Write("{0}\t", temp);
            }
            Console.WriteLine();

            Console.WriteLine("Enter the number to be searched");
            int number = Convert.ToInt32(Console.ReadLine());
            int n = 0;
            foreach (int temp in num[0])// foreach loop to serach  number
            {
                if (number == temp)
                {
                    n = 1;
                }

            }
            foreach (int temp in num[1])
            {
                if (number == temp)
                {
                    n = 1;
                }

            }
            Console.WriteLine();
            if (n == 1)
            {
                Console.WriteLine("Number Found...");
            }
            else
            {
                Console.WriteLine("Number not Found");
            }
            Console.ReadLine();
        }

        public void SimpleInterest()
        {
            Console.WriteLine("--- Calculating Simple Interest ----");
            Console.WriteLine("Enter Principle amount");
            int p = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter  Rate of intersest");
            int r = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Time In Months");
            int t = Convert.ToInt32(Console.ReadLine());

            int Si = p * r * t; //formula to calculate simple interest
            int si1 = Si / 100; 
            Console.WriteLine("Simple Interest of Given amount is {0}",si1);
            Console.ReadLine();
        }

        public double SimplInt2(int pa,int ri,int t ,out double Si)
        {
            Console.WriteLine("--- Calculating simple interest ");
            Si = (pa * ri* t)/100; //Formula
            double total = pa +Si;
            return total;
        }

        public double GST(int amt,int gst =1)
        {
            Console.WriteLine("-- GST with default parameter value ---");
            return (amt*gst)/100; 
        }
    }

        
    }

