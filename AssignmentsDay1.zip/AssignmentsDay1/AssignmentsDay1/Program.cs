﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentsDay1
{
    class Program
    {
        static void Main(string[] args)
        {
            AreaofC a = new AreaofC();
            a.area();
            TypeCasting t = new TypeCasting();
            t.charToascii();
            t.ascciTochar();
            CurrencyConvo c = new CurrencyConvo();
            c.dollarToRs();
            c.rsTodollar();

        }
    }

    class AreaofC
    {
        public void area()
        {
            Console.WriteLine("--- Area of Circle ---");
            const double PI = 3.14;// must be inti
            //PI=3.15;// cant assigned
            Console.WriteLine("Enter Radius");
            int r = Convert.ToInt32(Console.ReadLine());//Accepting User Input
            double aoc = r * r * PI; //Calculating Area of circle
            Console.WriteLine("area of circle is " + aoc);
            Console.ReadLine();
        }
    }

    class TypeCasting
    {
        public void charToascii()
        {
            Console.WriteLine("--- Character  to ASCII ---");
            Console.WriteLine("Enter Any Alphabet");
            char c =Convert.ToChar( Console.ReadLine()); //Accepting User Input
            int ascii = Convert.ToInt32(c);//Conversion
            Console.WriteLine("After conversion the ASCII value of {0} is {1} ",c,ascii);
            Console.ReadLine();
        }

        public void ascciTochar()
        {
            Console.WriteLine("--- ASCII to Character ---");
            Console.WriteLine("Enter any ASCII value ");
            int a = Convert.ToInt32(Console.ReadLine());//Accepting User Input
            char ch = Convert.ToChar(a);//Conversion
            Console.WriteLine("After conversion the char value of {0} is {1} ",a, ch);
            Console.ReadLine();
        }
    }
    class CurrencyConvo
    {
        public void dollarToRs()
        {
            Console.WriteLine("--- Dollars to Rupees ---");
            Console.WriteLine("Enter amount in Dollars ");
            double dollar = Convert.ToDouble(Console.ReadLine());//Accepting User Input
            int rs = Convert.ToInt32(dollar * 71);//Conversion
            Console.WriteLine("{0} Dollars in Rupees is {1} Rupees ",dollar,rs);
            Console.ReadLine();
        }
       public void rsTodollar()
        {
            Console.WriteLine("Enter Amount in Rupees");
            int rupee = Convert.ToInt32(Console.ReadLine());//Accepting User Input
            double doll = Convert.ToDouble(rupee / 71.06);//Conversion
            Console.WriteLine("{0} Rupees in Dollars is {1} Dollars ",rupee,doll);
            Console.ReadLine();
        }
    }
}
