﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Main Function
            assignment4 a = new assignment4();
            a.reverse();
            a.Dowhileas();
            a.foreachOdd();
            a.foreachEven();
            a.table();
        }
    }

    class assignment4
    {
        
        public void reverse()
        {
            Console.WriteLine("--- REVERSE NUMBERS ---");
           
            for (int i = 50; i >= 1; i--) //For Loop Which will print numbers in reverse order
            {
                Console.WriteLine(i);
               
            }
            Console.ReadLine();
        }

        public void Dowhileas()
        {
            Console.WriteLine("--- DO WHILE ODD NUMBERS ---");

            int number = 1;
            do
            {
                if (number % 2 != 0)//Condition
                {
                    Console.WriteLine(number);
                }
                number++; //incement of number
            } while (number <= 50);// loop will Continue until number becomes 50
            Console.ReadLine();
        }

        public void foreachOdd()
        {
            Console.WriteLine("--- FOREACH ODD ---");
            int[] num = new int[50]; //array
            for(int i=0; i<50;i++)
            {
                num[i] = i + 1; // adding 50 numbers to array
            }
            foreach(int temp in num)
            {
                if(temp % 2!=0)//Condition
                {
                    Console.WriteLine(temp); //Printing Odd Numbers to Array
                }

            }
            Console.ReadLine();
        }
        public void foreachEven()
        {
            Console.WriteLine("--- FOREACH EVEN ---");
            int[] num =new int[50];// array
            for(int i=1;i<50;i++)
            {
                num[i] = i + 1;// adding 50 numbers to array
            }
            foreach(int temp in num)
            {
                if(temp%2==0)
                {
                    Console.WriteLine(temp); //printing Even Numbers of array
                }
            }
            Console.ReadLine();

        }


        public void table()
        {
            Console.WriteLine("--- TABLE OF GIVEN NUMBERS ---");
            Console.WriteLine("Enter The Number of which you want table");
            int table = Convert.ToInt32(Console.ReadLine());// Accepting User Input
            Console.Write("\n\n");
            
                for(int j=1;j<=10;j++)
                {
                  
                    Console.WriteLine("{0} * {1}={2}\n",table,j,table*j);// Printing table
                    
                }
            
            Console.ReadLine();
        }
    }
}
